# Modern Software Engineer Portfolio & ATS Resume Starter

A high-performance, responsive portfolio website and ATS-friendly printable resume built with React 18, TypeScript, Tailwind CSS, and Vite.

## 🚀 Quick Setup (3 Minutes)

1. **Install dependencies**:
   ```bash
   npm install
   ```

2. **Personalize Your Portfolio**:
   Open `src/data/portfolio.ts` and replace the information with your own details:
   - Your name, headline, and bio
   - Your work experience & achievements
   - Your featured projects & system architecture flows
   - Your skills & contact links (email, phone, LinkedIn, GitHub, X)

3. **Start the local dev server**:
   ```bash
   npm run dev
   ```
   Open http://localhost:5173 to view your live portfolio!

4. **Build & Deploy**:
   ```bash
   npm run build
   ```
   Deploy with 1 click to **Vercel**, **Netlify**, or **GitHub Pages**.

## 📄 ATS Resume
Your standalone printable resume is located at `public/resume.html`. Simply update your details and click **"Print / Save PDF"** in your browser!
